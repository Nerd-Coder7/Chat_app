import "./App.css";
import SignUp from "./Component/SignUp";

function App() {
  return (
    <div>
      <SignUp />
    </div>
  );
}

export default App;
