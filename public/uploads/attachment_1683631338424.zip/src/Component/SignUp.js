import React from "react";

const SignUp = () => {
  return (
    <div className=" lg:flex  h-screen">
      {/* SignUp */}
      <div className=" lg:w-[70%] h-screen ">
        {/* Logo Part */}
        <div className="p-[30px] ">
          <img src="awslogo.png" alt="logo" className="w-[120px] h-[40px]" />
        </div>

        {/* Feilds */}
        <div className="mt-[70px] flex flex-col items-center text-center ">
          <h1 className="text-4xl md:text-5xl font-bold p-[15px] m-[10px]">
            Create Account
          </h1>
          <input
            type="text"
            placeholder="Enter your name"
            className="bg-slate-200 h-[50px] mt-5  p-[15px] rounded-full text-lg font-semibold md:w-[60%]"
          />
          <input
            type="text"
            placeholder="Enter your email"
            className="bg-slate-200 h-[50px] mt-5  p-[15px] rounded-full text-lg font-semibold md:w-[60%]"
          />
          <input
            type="text"
            placeholder="Enter your password"
            className="bg-slate-200 h-[50px] mt-5  p-[15px] rounded-full text-lg font-semibold md:w-[60%]"
          />
          <input
            type="text"
            placeholder="Confirm password"
            className="bg-slate-200 h-[50px] mt-5  p-[15px] rounded-full text-lg font-semibold md:w-[60%]"
          />
        </div>
        <div className="flex justify-center m-5">
          <button className="block bg-orange-500 w-[50%] h-[60px] rounded-full mt-5 text-xl font-bold md:w-[50%] lg:[50%] ">
            SignUp
          </button>
        </div>
      </div>
      {/* Login Button */}
      <div className="  lg:w-[30%] bg-gradient-to-r from-orange-400 to-orange-500 flex justify-center items-center">
        <div className="flex flex-col items-center gap-5 text-center p-[15px]">
          <h1 className="text-2xl md:text-4xl font-bold">Already a user?</h1>
          <h1 className="text-xl md:text-2xl ">
            Login and discover a great <br /> amount of new opportunities!
          </h1>
          <button className=" bg-black text-white w-[80%] h-[60px] rounded-full mt-5 text-xl font-bold ">
            Login
          </button>
        </div>
      </div>
    </div>
  );
};

export default SignUp;
