import React, { useState } from "react";

const Chatbox = () => {
  const [userList, setUserList] = useState(false);

  console.log(userList);

  return (
    <div className="md:flex">
      {/* Left Side  */}
      <div
        className={`${
          userList ? "block" : "hidden"
        } md:block bg-[#1f1f1f]  md:w-[50%] lg:w-[30%] h-screen overflow-y-auto`}
      >
        <div className=" p-3 md:p-5">
          {/* Login User */}
          <div className="flex items-center gap-4  md:gap-7 ">
            <img
              src="images.jpg"
              alt="avatar"
              className=" w-10 h-10 rounded-full p-1 ring-2 ring-orange-400 md:w-16 md:h-16"
            />
            <h1 className="font-bold text-xl md:text-2xl text-white">
              Mike Ross
            </h1>
          </div>
        </div>
        {/* Search  */}
        <div>
          <input
            type="text"
            placeholder="Search User..."
            className="w-[100%] h-12 bg-[#363636] p-5 font-semibold md:font-bold rounded-md text-white "
          />
        </div>
        {/* Previous Chats */}
        <div className="p-2 md:p-5 flex flex-col gap-5 md:gap-8">
          <div className="flex items-center gap-5">
            <div className="relative">
              <img
                className="w-9 h-9 md:w-12 md:h-12 rounded-full"
                src="images.jpg"
                alt=""
              />
              <span className="top-0 left-6 md:left-8 absolute  w-2.5 h-2.5 md:w-3.5 md:h-3.5 bg-green-400 border-2 border-[#1f1f1f]  rounded-full"></span>
            </div>
            <div className="text-white">
              <h1 className="font-semibold text-sm md:font-bold md:text-md ">
                User 1
              </h1>
              <p className="text-xs md:text-md">this is the latest message</p>
            </div>
          </div>
          <div className="flex items-center gap-5">
            <div className="relative">
              <img
                className="w-9 h-9 md:w-12 md:h-12 rounded-full"
                src="images.jpg"
                alt=""
              />
              <span className="top-0 left-6 md:left-8 absolute  w-2.5 h-2.5 md:w-3.5 md:h-3.5 bg-red-400 border-2 border-[#1f1f1f]  rounded-full"></span>
            </div>
            <div className="text-white">
              <h1 className="font-semibold text-sm md:font-bold md:text-md ">
                User 1
              </h1>
              <p className="text-xs md:text-md">this is the latest message</p>
            </div>
          </div>
          <div className="flex items-center gap-5">
            <div className="relative">
              <img
                className="w-9 h-9 md:w-12 md:h-12 rounded-full"
                src="images.jpg"
                alt=""
              />
              <span className="top-0 left-6 md:left-8 absolute  w-2.5 h-2.5 md:w-3.5 md:h-3.5 bg-yellow-400 border-2 border-[#1f1f1f]  rounded-full"></span>
            </div>
            <div className="text-white">
              <h1 className="font-semibold text-sm md:font-bold md:text-md ">
                User 1
              </h1>
              <p className="text-xs md:text-md">this is the latest message</p>
            </div>
          </div>
          <div className="flex items-center gap-5">
            <div className="relative">
              <img
                className="w-9 h-9 md:w-12 md:h-12 rounded-full"
                src="images.jpg"
                alt=""
              />
              <span className="top-0 left-6 md:left-8 absolute  w-2.5 h-2.5 md:w-3.5 md:h-3.5 bg-slate  -400 border-2 border-[#1f1f1f]  rounded-full"></span>
            </div>
            <div className="text-white">
              <h1 className="font-semibold text-sm md:font-bold md:text-md ">
                User 1
              </h1>
              <p className="text-xs md:text-md">this is the latest message</p>
            </div>
          </div>
          <div className="flex items-center gap-5">
            <div className="relative">
              <img
                className="w-9 h-9 md:w-12 md:h-12 rounded-full"
                src="images.jpg"
                alt=""
              />
              <span className="top-0 left-6 md:left-8 absolute  w-2.5 h-2.5 md:w-3.5 md:h-3.5 bg-green-400 border-2 border-[#1f1f1f]  rounded-full"></span>
            </div>
            <div className="text-white">
              <h1 className="font-semibold text-sm md:font-bold md:text-md ">
                User 1
              </h1>
              <p className="text-xs md:text-md">this is the latest message</p>
            </div>
          </div>
          <div className="flex items-center gap-5">
            <div className="relative">
              <img
                className="w-9 h-9 md:w-12 md:h-12 rounded-full"
                src="images.jpg"
                alt=""
              />
              <span className="top-0 left-6 md:left-8 absolute  w-2.5 h-2.5 md:w-3.5 md:h-3.5 bg-green-400 border-2 border-[#1f1f1f]  rounded-full"></span>
            </div>
            <div className="text-white">
              <h1 className="font-semibold text-sm md:font-bold md:text-md ">
                User 1
              </h1>
              <p className="text-xs md:text-md">this is the latest message</p>
            </div>
          </div>
          <div className="flex items-center gap-5">
            <div className="relative">
              <img
                className="w-9 h-9 md:w-12 md:h-12 rounded-full"
                src="images.jpg"
                alt=""
              />
              <span className="top-0 left-6 md:left-8 absolute  w-2.5 h-2.5 md:w-3.5 md:h-3.5 bg-green-400 border-2 border-[#1f1f1f]  rounded-full"></span>
            </div>
            <div className="text-white">
              <h1 className="font-semibold text-sm md:font-bold md:text-md ">
                User 1
              </h1>
              <p className="text-xs md:text-md">this is the latest message</p>
            </div>
          </div>
        </div>
      </div>
      {/* Right Side */}
      <div
        className={`${
          userList ? "hidden" : "block"
        } w-[100%] md:w-[70%] relative bg-slate-200 h-screen md:block`}
      >
        <div className=" p-3 md:p-5 bg-white h-[60px] md:h-[100px]">
          <div className="flex items-center gap-3">
            <img
              src="arrow.png"
              alt=""
              className="h-4 w-4 md:hidden"
              onClick={() => setUserList(true)}
            />
            <img
              src="images.jpg"
              alt=""
              className=" w-7 h-7 rounded-full md:w-10 md:h-10"
            />
            <h1 className="text-[md] font-semibold md:text-2xl">
              {" "}
              Harvey Specter
            </h1>
          </div>
        </div>
        {/* Messages */}
        <div className="p-2 md:p-5 h-[calc(100vh-110px)] md:h-[calc(100vh-150px)] overflow-y-auto">
          <div className="flex flex-col">
            <div className="flex justify-end items-center ">
              <p className="text-xs md:text-sm p-[5px] md:p-[10px] bg-white m-1 rounded-md  text-slate-800  ">
                this is a dummy message
              </p>
              <img
                src="images.jpg"
                alt=""
                className="w-5 h-5 rounded-full md:w-8 md:h-8"
              />
            </div>
            <div className="flex justify-start items-center ">
              <img
                src="images.jpg"
                alt=""
                className="w-5 h-5 rounded-full md:w-8 md:h-8"
              />
              <p className="text-xs md:text-sm p-[5px] md:p-[10px] bg-orange-400 m-1 rounded-md text-black ">
                this is a dummy message
              </p>
            </div>
            <div className="flex justify-start items-center ">
              <img
                src="images.jpg"
                alt=""
                className="w-5 h-5 rounded-full md:w-8 md:h-8"
              />
              <p className="text-xs md:text-sm p-[5px] md:p-[10px] bg-orange-400 m-1 rounded-md text-black ">
                this is a dummy message
              </p>
            </div>
            <div className="flex justify-start items-center ">
              <img
                src="images.jpg"
                alt=""
                className="w-5 h-5 rounded-full md:w-8 md:h-8"
              />
              <p className="text-xs md:text-sm p-[5px] md:p-[10px] bg-orange-400 m-1 rounded-md text-black ">
                this is a dummy message
              </p>
            </div>
            <div className="flex justify-start items-center ">
              <img
                src="images.jpg"
                alt=""
                className="w-5 h-5 rounded-full md:w-8 md:h-8"
              />
              <p className="text-xs md:text-sm p-[5px] md:p-[10px] bg-orange-400 m-1 rounded-md text-black ">
                this is a dummy message
              </p>
            </div>
            <div className="flex justify-end items-center ">
              <p className="text-xs md:text-sm p-[5px] md:p-[10px] bg-white m-1 rounded-md  text-slate-800  ">
                this is a dummy message
              </p>
              <img
                src="images.jpg"
                alt=""
                className="w-5 h-5 rounded-full md:w-8 md:h-8"
              />
            </div>
            <div className="flex justify-end items-center ">
              <p className="text-xs md:text-sm p-[5px] md:p-[10px] bg-white m-1 rounded-md  text-slate-800  ">
                this is a dummy message
              </p>
              <img
                src="images.jpg"
                alt=""
                className="w-5 h-5 rounded-full md:w-8 md:h-8"
              />
            </div>
            <div className="flex justify-end items-center ">
              <p className="text-xs md:text-sm p-[5px] md:p-[10px] bg-white m-1 rounded-md  text-slate-800  ">
                this is a dummy message
              </p>
              <img
                src="images.jpg"
                alt=""
                className="w-5 h-5 rounded-full md:w-8 md:h-8"
              />
            </div>
            <div className="flex justify-end items-center ">
              <p className="text-xs md:text-sm p-[5px] md:p-[10px] bg-white m-1 rounded-md  text-slate-800  ">
                this is a dummy message
              </p>
              <img
                src="images.jpg"
                alt=""
                className="w-5 h-5 rounded-full md:w-8 md:h-8"
              />
            </div>
            <div className="flex justify-end items-center ">
              <p className="text-xs md:text-sm p-[5px] md:p-[10px] bg-white m-1 rounded-md  text-slate-800  ">
                this is a dummy message
              </p>
              <img
                src="images.jpg"
                alt=""
                className="w-5 h-5 rounded-full md:w-8 md:h-8"
              />
            </div>
            <div className="flex justify-start items-center ">
              <img
                src="images.jpg"
                alt=""
                className="w-5 h-5 rounded-full md:w-8 md:h-8"
              />
              <p className="text-xs md:text-sm p-[5px] md:p-[10px] bg-orange-400 m-1 rounded-md text-black ">
                this is a dummy message
              </p>
            </div>
            <div className="flex justify-start items-center ">
              <img
                src="images.jpg"
                alt=""
                className="w-5 h-5 rounded-full md:w-8 md:h-8"
              />
              <p className="text-xs md:text-sm p-[5px] md:p-[10px] bg-orange-400 m-1 rounded-md text-black ">
                this is a dummy message
              </p>
            </div>
            <div className="flex justify-start items-center ">
              <img
                src="images.jpg"
                alt=""
                className="w-5 h-5 rounded-full md:w-8 md:h-8"
              />
              <p className="text-xs md:text-sm p-[5px] md:p-[10px] bg-orange-400 m-1 rounded-md text-black ">
                this is a dummy message
              </p>
            </div>
            <div className="flex justify-start items-center ">
              <img
                src="images.jpg"
                alt=""
                className="w-5 h-5 rounded-full md:w-8 md:h-8"
              />
              <p className="text-xs md:text-sm p-[5px] md:p-[10px] bg-orange-400 m-1 rounded-md text-black ">
                this is a dummy message
              </p>
            </div>
            <div className="flex justify-start items-center ">
              <img
                src="images.jpg"
                alt=""
                className="w-5 h-5 rounded-full md:w-8 md:h-8"
              />
              <p className="text-xs md:text-sm p-[5px] md:p-[10px] bg-orange-400 m-1 rounded-md text-black ">
                this is a dummy message
              </p>
            </div>
          </div>
        </div>

        {/* Footer */}
        <div className=" flex items-center absolute bottom-0 bg-white left-0 w-[100%]">
          <img
            src="attachment.png"
            alt=""
            className="h-4 w-4 m-2   md:h-5 md:w-5 "
          />
          <input
            type="text"
            placeholder="Write your message.."
            className="w-[100%] h-[50px] p-[10px]"
          />

          <button className="bg-orange-400 p-[10px] text-sm font-bold">
            <img src="paper-plane.png" alt="" className="w-5 h-5" />
          </button>
        </div>
      </div>
    </div>
  );
};

export default Chatbox;
