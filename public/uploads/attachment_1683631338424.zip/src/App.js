import "./App.css";
import Chatbox from "./Component/Chatbox";
import SignUp from "./Component/SignUp";
import { Routes, Route } from "react-router-dom";

function App() {
  return (
    <div>
      <Routes>
        <Route path="/" element={<SignUp />} />
        <Route path="/chatbox" element={<Chatbox />} />
      </Routes>
    </div>
  );
}

export default App;
