const express = require("express");
const router = express.Router()
const  creatercontroller = require("../controller/creater")
router.post("/addcreater",creatercontroller.add_creater)
module.exports = router