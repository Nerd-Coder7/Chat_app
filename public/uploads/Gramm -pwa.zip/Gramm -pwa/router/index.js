const express = require("express");
const router = express.Router()

const userRouter = require("./user")
router.use("/user",  userRouter)

const createrRouter = require("./creater")
router.use("/creater",  createrRouter)

module.exports = router