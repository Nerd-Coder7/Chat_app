const express = require("express");
const router = express.Router()
const userController = require("../controller/user")
const middleware = require("../helper/middleware")
router.post("/verifyuser",userController.verifyuser)
router.post("/signup",userController.signup)
router.post("/login",userController.login)
router.post("/resetPassword",userController.resetPassword)
router.get("/userdetail",middleware.validateUser,userController.userdetail)
module.exports= router