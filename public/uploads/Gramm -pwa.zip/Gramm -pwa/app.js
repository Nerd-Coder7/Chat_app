var express = require('express');
require('dotenv').config()
var app = express();
const cors = require('cors')
const morgan = require('morgan')
const AWS = require('aws-sdk');
const otpGenerator = require("otp-generator")
const s3 = new AWS.S3();
const AWS_ACCESS_KEY_ID = process.env.AWS_ACCESS_KEY_ID
const AWS_SECRET_ACCESS_KEY = process.env.AWS_SECRET_ACCESS_KEY 

const params = {
    Bucket: 'gramm-pwa',
    Key: '_______________________________',
    Body: 'Hello World!'
  };
  
  s3.putObject(params, function(err, data) {
    if (err) {
      console.log(err, err.stack);
    } else {
        
      console.log('Successfully uploaded data to ' + params.Bucket + '/' + params.Key);
    }
  });
  
app.use(express.json())
app.use(morgan())
app.use(cors())
app.use(express.urlencoded({ extended: false }))
app.use('/images', express.static(__dirname + '/uploads'));

const router = require("./router/index")
app.use("/v1", router);
app.use('/', require("./router/index"))
const connection = require("./connection/connection")


app.listen(4000, async (err) => {
  if (err) {
    console.log(err)
  }
  console.log("server is run  4000")
  connection.connection()
})






