
const jwt = require("jsonwebtoken");
const user = require("../model/user");
module.exports = {
  validateUser: async function (req, res, next) {
    const token = req.headers.token
    if (!token) {
        return res.status(404).send(" token not exist")
    }
    let userExist = await user.findOne({ token: token })
    if (!userExist) {
        return res.status(400).send(" this token not exist")
    }
    req.decode = userExist
    next()
  }
}