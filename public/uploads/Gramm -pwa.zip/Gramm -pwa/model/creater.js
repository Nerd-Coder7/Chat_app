const mongoose = require('mongoose');

const createrSchema = mongoose.Schema({
    first_name: { type: String, require: true, default: "" },
    last_name: { type: String, require: true, },
    phone :{ type: String, require: true, default: "" },
    email: { type: String, require: true },
    platform: [{ type: String}],
    instagram_username :{ type: String, require: true,default: ""},
    snapchat_username :{ type: String, require: true,default: ""}
}, {
    timestamps: true
});

module.exports = mongoose.model('creater', createrSchema);