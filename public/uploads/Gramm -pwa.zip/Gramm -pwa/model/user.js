
const mongoose = require('mongoose');

const UserSchema = mongoose.Schema({
    username: { type: String, require: true, default: "" },
    date_of_birth: { type: String, require: true, },
    phone :{ type: String, require: true, default: "" },
    gender: { type: String, enum: ["female", "male"], required: true },
    email: { type: String, require: true },
    password: { type: String, require: true },
    Bio :{ type: String, require: true, default: "" },
    token:{ type: String},
}, {
    timestamps: true
});

module.exports = mongoose.model('User', UserSchema);