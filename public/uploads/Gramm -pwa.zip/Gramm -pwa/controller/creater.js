const createrModel = require("../model/creater")
const { securePassword, comparePassword, validateRequest } = require("../helper/helper");


module.exports = {
    async add_creater(req, res) {
        try {
            let validate = validateRequest(req.body, ['first_name','last_name','phone','email','platform','instagram_username', 'snapchat_username'])
            if (validate && !validate.status && validate.msg) {
                return res.status(400).send(validate.msg)
            }
            const data = await createrModel.create(req.body)
            if (!data) {
                return res.status(400).send("something went wrong")
            } else {
                return res.status(200).send({message:"data created successfully",data: data})
            }
        } catch (e) {
            return res.status(500).send(e)
        }
    }
}