const userModel = require("../model/user")
const otpGenerator = require("otp-generator")
const nodemailer = require("nodemailer")
const { validateSignup, validatelogin } = require("../helper/validation");
const { securePassword, comparePassword, validateRequest } = require("../helper/helper");
const jwt = require("jsonwebtoken")
const { verify } = require("jsonwebtoken");
module.exports = {
    async verifyuser(req, res) {
        try {
            const { email, phone } = req.body

            const emailExist = await userModel.findOne({ email: email })
            if (emailExist) {
                return res.status(404).send("user already exist")
            }
            if (email) {
                var transporter = nodemailer.createTransport({
                    service: "gmail",
                    auth: {
                        user: "nakitaaronwebsolutions@gmail.com",
                        pass: "wslfwyqhiekvzpvj",
                    },
                });
                const link = `http://localhost:4000/verify-user/`
                let emailHtml = `
            <!doctype html>
            <html lang="en-US">
            <head>
                <meta content="text/html; charset=utf-8" http-equiv="Content-Type" />
                <title>verify user Template</title>
                <meta name="description" content="verify user Template.">
                <style type="text/css">
                    a:hover {text-decoration: underline !important;}
                </style>
            </head>
            <body marginheight="0" topmargin="0" marginwidth="0" style="margin: 0px; background-color: #F2F3F8;" leftmargin="0">
                <!--100% body table-->
                <table cellspacing="0" border="0" cellpadding="0" width="100%" bgcolor="#F2F3F8"
                    style="@import url(https://fonts.googleapis.com/css?family=Rubik:300,400,500,700%7COpen+Sans:300,400,600,700); font-family: 'Open Sans', sans-serif;">
                    <tr>
                        <td>
                            <table style="background-color: #F2F3F8; max-width:670px;  margin:0 auto;" width="100%" border="0"
                                align="center" cellpadding="0" cellspacing="0">
                                <tr>
                                    <td style="height:80px;">&nbsp;</td>
                                </tr>
                                <tr>
                                    <td style="height:20px;">&nbsp;</td>
                                </tr>
                                <tr>
                                    <td>
                                        <table width="95%" border="0" align="center" cellpadding="0" cellspacing="0"
                                            style="max-width:670px;background:#fff; border-radius:3px; text-align:center;-webkit-box-shadow:0 6px 18px 0 rgba(0,0,0,.06);-moz-box-shadow:0 6px 18px 0 rgba(0,0,0,.06);box-shadow:0 6px 18px 0 rgba(0,0,0,.06);">
                                            <tr>
                                                <td style="height:40px;">&nbsp;</td>
                                            </tr>
                                            <tr>
                                                <td style="padding:0 35px;">
                                                    <h1 style="color:#1e1e2d; font-weight:500; margin:0;font-size:32px;font-family:'Rubik',sans-serif;">You have
                                                        requested to verify  user</h1>
                                                    <span
                                                        style="display:inline-block; vertical-align:middle; margin:29px 0 26px; border-bottom:1px solid #CECECE; width:100px;"></span>
                                                    <p style="color:#455056; font-size:15px;line-height:24px; margin:0;">
                                                        This is A unique link to verify 
                                                        user. To verify user, click the
                                                        following link.
                                                    </p>
                                                    <a href="${link}"
                                                        style="background:#20e277;text-decoration:none !important; font-weight:500; margin-top:35px; color:#fff;text-transform:uppercase; font-size:14px;padding:10px 24px;display:inline-block;border-radius:50px;">verify User</a>
                                                </td>
                                            </tr>
                                            <tr>
                                                <td style="height:40px;">&nbsp;</td>
                                            </tr>
                                        </table>
                                    </td>
                                <tr>
                                    <td style="height:20px;">&nbsp;</td>
                                </tr>
                                <tr>
                                    <td style="height:80px;">&nbsp;</td>
                                </tr>
                            </table>
                        </td>
                    </tr>
                </table>
                <!--/100% body table-->
            </body>
            </html>`
                var mailOptions = {
                    from: "nakitaaronwebsolutions@gmail.com",
                    to: email,
                    subject: "verify user",
                    html: emailHtml
                };
                transporter.sendMail(mailOptions, function (error, result) {
                    if (error) {
                        console.log("Email error sent: " + JSON.stringify(error));
                        return res.status(400).send(error)
                    } else {
                        console.log("Email result sent: " + JSON.stringify(result));
                        return res.status(200).send("send mail successfully")
                    }
                });
            } else {
                var accountSid = process.env.TWILIO_ACCOUNT_SID
                var authToken = process.env.TWILIO_AUTH_TOKEN;
                const OTP = otpGenerator.generate(5, {
                    alphabets: false, specialChars: false, digits: true,
                    lowerCaseAlphabets: false, upperCaseAlphabets: false,
                });
                var twilio = require("twilio");
                var client = new twilio(accountSid, authToken);

                client.messages
                    .create({
                        body: `${OTP} is your otp code`,
                        to: phone,
                        from: "+15204413521",
                    })
                    .then((message) => res.send(` message sent successfully !`));
            }
        } catch (e) {
            console.log(e)
            return res.status(500).send(e)
        }
    },
    async signup(req, res) {
        try {
            const { error } = validateSignup(req.body);
            if (error) {
                console.log(error);
                return res.status(400).send({ message: error.message });
            }
            const hash = await securePassword(req.body.password)
            const result = await userModel.create({
                username: req.body.username,
                date_of_birth: req.body.date_of_birth,
                email: req.body.email,
                password: hash,
                gender: req.body.gender
            })
            if (!result) {
                res.status(400).send("something went wrong")
            } else {
                console.log(result)
                return res.status(200).send({ message: "signup successfully", result: result })
            }
        } catch (e) {
            console.log(e)
            return res.status(500).send(e)
        }
    },
    async login(req, res) {
        try {
            const { email, password } = req.body
            const { error } = validatelogin(req.body);
            if (error) {
                console.log(error);
                return res.status(400).send({ message: error.message });
            }
            const userExist = await userModel.findOne({ email: email })
            if (!userExist) {
                return res.status(400).send("user not found")
            } else {
                if (userExist) {
                    console.log(userExist)
                    const compassword = await comparePassword(password, userExist.password);
                    if (!compassword) {
                        return res.status(400).send("password is wrong")
                    }
                    else {
                        const token = jwt.sign({
                            id: userExist._id,
                            email: email
                        }, process.env.TOKEN_SECRET, { expiresIn: "7d" })
                        console.log(token, "token______________")
                        let newUser = await userModel.findOneAndUpdate({ email: email }, { token: token }, { new: true })
                        return res.status(200).send({ message: "login successfully", token: token, user: newUser })
                    }
                }
            }
        } catch (e) {
            console.log(e)
            return res.status(500).send(e)
        }
    },
    async resetPassword(req, res) {
        try {
            const { email, password } = req.body
            if (!email || !password) {
                return res.status(400).send("required the field")
            }
            const emailexist = await userModel.findOne({ email: email })
            if (!emailexist) {
                return res.status(404).send("email not exist")
            }
            console.log(password)
            const hash = await securePassword(password)
            const result = await userModel.findByIdAndUpdate({ _id: emailexist._id }, { password: hash }, { new: true })
            if (!result) {
                return res.status(404).send("something went wrong")
            } else {
                return res.status(200).send("password change successfully")
            }
        } catch (err) {
            return res.status(500).send(err)
        }
    },
    async userdetail(req, res) {
        try {
            const tokenUser = req.decode
            const result = await userModel.findOne({ _id: tokenUser._id })
            const { token, createdAt, updatedAt, password, _id, ...otherDetails } = result._doc;
            if (!result) {
                return res.status(404).send("user not exist")
            } else {
                return res.status(200).send({ message: "get detail successfully", result: otherDetails })
            }
        } catch (e) {
            return res.status(400).send(e)
        }
    }

}